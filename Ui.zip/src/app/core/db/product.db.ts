export const PRODUCTS: any[] = [];
