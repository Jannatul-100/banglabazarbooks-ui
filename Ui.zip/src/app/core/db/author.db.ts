export const AUTHORS: any[] = [];
