import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { SeoService } from '../../../services/core/seo.service';

@Component({
  selector: 'app-payment-status',
  templateUrl: './payment-status.component.html',
  styleUrls: ['./payment-status.component.scss'],
  standalone: true,
  imports: [CommonModule, RouterModule, MatButtonModule, MatIconModule, TranslateModule]
})
export class PaymentStatusComponent implements OnInit {
  // Signals
  status = signal<'success' | 'fail' | 'cancel'>('success');
  orderId = signal<string | null>(null);
  failMessage = signal<string | null>(null);

  // Dependencies
  private route = inject(ActivatedRoute);
  private seoService = inject(SeoService);

  ngOnInit(): void {
    this.seoService.clearSchema();
    this.seoService.updateMetaData({ title: 'Payment Status', noIndex: true });
    const path = this.route.snapshot.url.map(segment => segment.path).join('/');
    if (path.includes('success')) this.status.set('success');
    else if (path.includes('fail')) this.status.set('fail');
    else if (path.includes('cancel')) this.status.set('cancel');

    this.orderId.set(this.route.snapshot.queryParamMap.get('orderId'));
    this.failMessage.set(this.route.snapshot.queryParamMap.get('message'));
  }
}
