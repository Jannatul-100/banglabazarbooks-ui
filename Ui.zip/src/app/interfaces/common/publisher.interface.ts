export interface Publisher {
  _id?: string;
  slug?: string;
  select?: any;
  name?: string;
  nameEn?: string;
  image?: string;
  createdAt?: Date;
  updatedAt?: Date;
}
 